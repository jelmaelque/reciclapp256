export default function App() {
  return <h1>App carregado! Em breve o formulário completo será inserido.</h1>;
}
